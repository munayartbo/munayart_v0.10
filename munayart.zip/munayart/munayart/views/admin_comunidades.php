<?php
session_start();
include '../controllers/db_connection.php';

// Verificar que el usuario tiene el rol de Administrador
if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'administrador') {
    echo "<script>alert('No tienes permiso para acceder aquí'); window.location.href = 'loginIniReg.php';</script>";
    exit();
}
// Consultar todos los usuarios (Clientes, Artesanos, Deliverys)
$sql_usuarios = "
    SELECT u.CodUsuario, u.Nombre, u.Apellido, u.Email, u.User, u.FechaNac, u.Celular,
           c.CodCliente, a.CodArtesano, a.Descripcion, a.AniosExp, a.FechaRegistro, a.Imagen, 
           d.CodDelivery, d.TipoVehiculo, d.Placa, d.ZonaCobertura, d.HoraIngreso, d.HoraSalida
    FROM Usuario u
    LEFT JOIN Cliente c ON u.CodUsuario = c.CodCliente
    LEFT JOIN Artesano a ON u.CodUsuario = a.CodArtesano
    LEFT JOIN Delivery d ON u.CodUsuario = d.CodDelivery
";
$result_usuarios = $conn->query($sql_usuarios);

// Consultar todas las promociones
$sql_promociones = "SELECT CodPromocion, Titulo, Descripcion, FechaInicio, FechaFin FROM promocion";
$result_promociones = $conn->query($sql_promociones);
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administrar Comunidades</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
            color: #333;
        }

        h1,
        h2 {
            text-align: center;
            color: #D64045;
        }

        h1 {
            padding: 20px;
            background-color: #D64045;
            color: white;
        }

        form {
            background-color: white;
            margin: 20px auto;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            max-width: 600px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }

        input[type="text"],
        input[type="number"],
        input[type="date"],
        textarea,
        select {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        button,
        input[type="submit"] {
            background-color: #D64045;
            color: white;
            border: none;
            padding: 10px 20px;
            text-align: center;
            font-size: 16px;
            cursor: pointer;
            border-radius: 4px;
            width: 100%;
        }

        button:hover,
        input[type="submit"]:hover {
            background-color: #45a049;
        }

        table {
            width: 90%;
            margin: 20px auto;
            border-collapse: collapse;
            background-color: white;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        th,
        td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: left;
        }

        th {
            background-color: #D64045;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        ul {
            list-style-type: none;
            padding: 0;
        }

        li {
            padding: 10px;
            background-color: white;
            margin: 10px auto;
            border-radius: 4px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 90%;
        }

        li a {
            color: ##D64045;
            text-decoration: none;
            font-weight: bold;
        }

        li a:hover {
            text-decoration: underline;
        }

        /* Estilos para el logo */
        .logo {
            position: absolute;
            top: 20px;
            left: 20px;
            width: 220px;
        }
    </style>
</head>

<body>
    

    <a href="admin_comunidades.php" class="logo"><img src="imagenes/LogoNombre.png" alt="Logo MunayArt"
            class="logo"></a>
    <h1>Panel de Administración</h1>
    <h2>Subir Comunidades</h2>
    <!-- Formulario para agregar comunidades -->
    <form action="../controllers/procesar_comunidad.php" method="post">
        <label for="nombre">Nombre de la Comunidad:</label>
        <input type="text" id="nombre" name="nombre" required><br>

        <label for="habitantes">Número de Habitantes:</label>
        <input type="number" id="habitantes" name="habitantes" required><br>

        <!-- Aquí irá la lógica para seleccionar el administrador (si lo deseas) -->
        <label for="admin">Administrador (ID):</label>
        <input type="text" id="admin" name="admin" required><br>

        <button type="submit">Agregar Comunidad</button>
    </form>

    <!-- Mostrar las comunidades existentes -->
    <h2>Lista de Comunidades</h2>
    <ul>
        <?php
        // Obtener comunidades desde la base de datos
        include '../controllers/db_connection.php'; // Conexión a la base de datos
        $sql = "SELECT * FROM comunidad";
        $result = $conn->query($sql);

        while ($row = $result->fetch_assoc()) {
            echo "<li>{$row['Nombre']} - Habitantes: {$row['NroHabitantes']} - <a href='../controllers/eliminar_comunidad.php?id={$row['CodComunidad']}' onclick='return confirm(\"¿Estás seguro de que deseas eliminar esta comunidad?\")'>Eliminar</a></li>";
        }

        $conn->close();
        ?>
    </ul>

    <!-- Sección de Usuarios -->
    <h2>Lista de Usuarios</h2>
    <?php
    if ($result_usuarios->num_rows > 0) {
        echo "<table border='1'>
                <thead>
                    <tr>
                        <th>CodUsuario</th>
                        <th>Nombre</th>
                        <th>Apellido</th>
                        <th>Email</th>
                        <th>Rol</th>
                        <th>Acción</th>
                    </tr>
                </thead>
                <tbody>";

        while ($row = $result_usuarios->fetch_assoc()) {
            $rol = '';

            if (!empty($row['CodCliente'])) {
                $rol = 'Cliente';
            } elseif (!empty($row['CodArtesano'])) {
                $rol = 'Artesano';
            } elseif (!empty($row['CodDelivery'])) {
                $rol = 'Delivery';
            } else {
                $rol = 'Administrador';
            }

            echo "<tr>
                    <td>{$row['CodUsuario']}</td>
                    <td>{$row['Nombre']}</td>
                    <td>{$row['Apellido']}</td>
                    <td>{$row['Email']}</td>
                    <td>$rol</td>
                    
                    <td><a href='../controllers/eliminar_usuario.php?cod_usuario={$row['CodUsuario']}' onclick='return confirm(\"¿Estás seguro de que deseas eliminar este usuario?\")'>Eliminar</a></td>
                  </tr>";
        }

        echo "</tbody></table>";
    } else {
        echo "<p>No se encontraron usuarios.</p>";
    }
    ?>

    <!-- Sección de Promociones -->
    <h2>Lista de Promociones</h2>
    <?php
    // Mostrar tabla de promociones
    if ($result_promociones->num_rows > 0) {
        echo "<table border='1'>
            <thead>
                <tr>
                    <th>CodPromocion</th>
                    <th>Título</th>
                    <th>Descripción</th>
                    <th>Fecha Inicio</th>
                    <th>Fecha Fin</th>
                    <th>Acción</th>
                </tr>
            </thead>
            <tbody>";

        while ($row = $result_promociones->fetch_assoc()) {
            echo "<tr>
                <td>{$row['CodPromocion']}</td>
                <td>{$row['Titulo']}</td>
                <td>{$row['Descripcion']}</td>
                <td>{$row['FechaInicio']}</td>
                <td>{$row['FechaFin']}</td>
                <td><a href='../controllers/eliminar_promocion.php?cod_promocion={$row['CodPromocion']}' onclick='return confirm(\"¿Estás seguro de que deseas eliminar esta promoción?\")'>Eliminar</a></td>
              </tr>";
        }

        echo "</tbody></table>";
    } else {
        echo "<p>No se encontraron promociones.</p>";
    }
    ?>

    <h2>Añadir Promoción</h2>
    <form action="../controllers/procesar_promocion.php" method="POST">
        <label for="titulo">Título:</label>
        <input type="text" name="titulo" required><br>

        <label for="descripcion">Descripción:</label>
        <textarea name="descripcion" required></textarea><br>

        <label for="fecha_inicio">Fecha Inicio:</label>
        <input type="date" name="fecha_inicio" required>

        <label for="fecha_fin">Fecha Fin:</label>
        <input type="date" name="fecha_fin" required>

        <label for="producto">Producto:</label>
        <select name="producto" required>
            <?php
            // Consultar productos para la promoción
            include '../controllers/db_connection.php'; // Conexión a la base de datos
            $sql_productos = "SELECT CodProducto, Nombre FROM Producto";
            $result_productos = $conn->query($sql_productos);

            if ($result_productos === FALSE) {
                echo "<option value=''>Error en la consulta</option>";
            } else {
                if ($result_productos->num_rows > 0) {
                    while ($row = $result_productos->fetch_assoc()) {
                        echo "<option value='{$row['CodProducto']}'>{$row['Nombre']}</option>";
                    }
                } else {
                    echo "<option value=''>No hay productos disponibles</option>";
                }
            }
            ?>
        </select><br>

        <input type="submit" value="Añadir Promoción">
    </form>

    <script>
        function mostrarDetalles(codUsuario) {
            // Puedes mostrar los detalles del usuario en un modal o redirigir a una nueva página
            alert("Mostrar detalles del usuario: " + codUsuario);
        }
    </script>
</body>

</html>

<?php
// Cerrar conexión
$conn->close();
?>