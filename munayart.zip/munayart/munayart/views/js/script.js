/*Aquí va el script para recibir el mensaje desde el iframe*/

// Escucha el mensaje que viene del iframe 'encabezado.php'
window.addEventListener('message', function (event) {
    if (event.data.pagina) {
        // Cambia el src del iframe de contenido
        document.getElementById('contenido').src = event.data.pagina;
    }
});
