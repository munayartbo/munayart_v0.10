<?php
session_start();
if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'artesano') {
    echo "<script>
            alert('No tienes el rol de Artesano');
            window.location.href = '../views/loginIniReg.php';
          </script>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Subir Producto - MunayArt</title>
    <style>
        body {
            
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            color: #fff;
        }

        .container {
            background-color: #FFFFFF;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
            padding: 40px;
            max-width: 900px;
            width: 100%;
            text-align: center;
            position: relative;
        }

        h2 {
            color: #D64045;
            text-align: left;
        }

        form {
            margin-top: 20px;
        }

        label {
            font-size: 1.1em;
            margin-bottom: 5px;
            color: #333;
        }

        input[type="text"],
        input[type="number"],
        input[type="file"],
        select {
            width: 55%;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 5px;
            border: 1px solid #ccc;
            font-size: 1em;
        }

        .form-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr); /* Tres columnas */
            gap: 20px;
        }


        button {
            background-color: #D64045;
            color: white;
            border: none;
            padding: 10px;
            width: 40%;
            border-radius: 5px;
            font-size: 1em;
            cursor: pointer;
            margin-top: 10px;
        }

        button:hover {
            background-color: #b52e37;
        }

        input[type="submit"] {
            background-color: #467599;
            color: white;
            border: none;
            padding: 10px;
            width: 40%;
            border-radius: 5px;
            font-size: 1em;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #3c6484;
        }

        /* Estilos para el logo */
        .logo {
            position: absolute;
            top: 20px;
            left: 20px;
            width: 220px;
        }

    </style>
</head>
<body>
    <!-- Logo de MunayArt -->
    <a href="../index.php" class="logo"><img src="imagenes/LogoNombre.png" alt="Logo MunayArt" class="logo"></a>
    <div class="container">
        <h2>Subir Producto</h2>
        <form action="../controllers/procesar_subida.php" method="POST" enctype="multipart/form-data">
            <!-- Diseño en cuadrícula para campos del producto con tres columnas -->
            <div class="form-grid">
                <div>
                    <label for="nombre">Nombre:</label>
                    <input type="text" id="nombre" name="nombre" required>
                </div>
                <div>
                    <label for="tipo">Tipo:</label>
                    <select name="tipo" required>
                        <option value="Aretes">Aretes</option>
                        <option value="Cerámica">Cerámica</option>
                        <option value="Chompa">Chompa</option>
                        <option value="Collar">Collar</option>
                    </select>
                </div>
                <div>
                    <label for="precio">Precio:</label>
                    <input type="number" id="precio" name="precio" required>
                </div>
                <div>
                    <label for="material">Material:</label>
                    <input type="text" id="material" name="material" required>
                </div>
                <div>
                    <label for="dimensiones">Dimensiones:</label>
                    <input type="text" id="dimensiones" name="dimensiones" required>
                </div>
                <div>
                    <label for="cantidad">Cantidad en stock:</label>
                    <input type="number" name="cantidad" required>
                </div>

                <div>
                    <label for="descripcion">Descripción:</label>
                    <input type="text" id="descripcion" name="descripcion" required>
                </div>

                <div>
                    <label for="imagen">Imagen:</label>
                    <input type="file" id="imagen" name="imagen" accept="image/*" required>
                </div>
            </div>

            <button type="submit">Subir Producto</button>
        </form>

        <h2>Eliminar Producto</h2>
        <form action="../controllers/eliminar_producto.php" method="POST">
            <label for="nombre">Nombre del Producto:</label>
            <input type="text" name="nombre_producto" required><br>
            <input type="submit" value="Eliminar Producto">
        </form>

        <h2>Completar Datos del Artesano</h2>
        <form action="completar_datos_artesano.php" method="GET">
            <button type="submit">Completar Datos Artesano</button>
        </form>
    </div>
</body>
</html>
