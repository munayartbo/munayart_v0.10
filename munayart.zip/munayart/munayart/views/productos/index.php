<?php
// Iniciar la sesión antes de cualquier salida de HTML
session_start();
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MunayArt</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
    <link rel="stylesheet" href="./css/main.css">
</head>

<body>

    <div class="wrapper">
        <header class="header-mobile">
            <button class="open-menu" id="open-menu">
                <i class="bi bi-list"></i>
            </button>
        </header>
        <aside>
            <button class="close-menu" id="close-menu">
                <i class="bi bi-x"></i>
            </button>
            <header>
                <a href="../../index.php" class="logo"><img src="img/LogoNombre.png" width="250px"></a>
                <?php
                // Comprobar si el usuario ha iniciado sesión
                if (isset($_SESSION['user_name'])) {
                    $user_name = $_SESSION['user_name'];
                    echo "<h3>¡Bienvenido! $user_name</h3>";
                    echo "<a href='../logout.php' target='_top'>Cerrar sesión</a>";  // Enlace para cerrar sesión
                } else {
                    // Si no hay una sesión de usuario, redirigir al login
                    echo "<h3>¡Bienvenido!</h3>";
                }
                ?>
            </header>
            <nav>
                <ul class="menu">
                    <li>
                        <button id="todos" class="boton-menu boton-categoria active"><i
                                class="bi bi-hand-index-thumb-fill"></i> Todos los productos</button>
                    </li>
                    <li>
                        <button id="Aretes" class="boton-menu boton-categoria"><i class="bi bi-hand-index-thumb"></i>
                            Aretes</button>
                    </li>
                    <li>
                        <button id="Cerámica" class="boton-menu boton-categoria"><i class="bi bi-hand-index-thumb"></i>
                            Cerámica</button>
                    </li>
                    <li>
                        <button id="Chompa" class="boton-menu boton-categoria"><i class="bi bi-hand-index-thumb"></i>
                            Chompas</button>
                    </li>
                    <li>
                        <button id="Collar" class="boton-menu boton-categoria"><i class="bi bi-hand-index-thumb"></i>
                            Collares</button>
                    </li>
                    <li>
                        <a class="boton-menu boton-carrito" href="carrito.php">
                            <i class="bi bi-cart-fill"></i> Carrito <span id="numerito" class="numerito">0</span>
                        </a>
                    </li>
                </ul>
            </nav>
            <footer>
                <p class="texto-footer">© 2024 MunayArt</p>
            </footer>
        </aside>
        <main>
            <h2 class="titulo-principal" id="titulo-principal">Todos los productos</h2>
            <div id="contenedor-productos" class="contenedor-productos">
                <!-- Esto se va a rellenar con JS -->
            </div>
        </main>
    </div>

    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
    <script src="js/main.js"></script>
    <script src="js/menu.js"></script> <!-- Asegúrate de que esta línea esté presente -->


    <script>
        window.onload = function () {
            // Obtener el parámetro de la categoría de la URL
            const params = new URLSearchParams(window.location.search);
            const categoria = params.get('categoria');

            // Verificar si hay una categoría seleccionada en la URL
            if (categoria) {

                // Cambiar el título principal al nombre de la categoría seleccionada
                tituloPrincipal.innerText = categoria;

                // Filtrar los productos que coincidan con la categoría
                const productosFiltrados = productos.filter(producto => producto.tipo.toLowerCase() === categoria.toLowerCase());

                // Cargar los productos filtrados
                cargarProductos(productosFiltrados);
                //window.alert("si");

                // Cambiar la clase del botón de categoría seleccionada
                botonesCategorias.forEach(boton => {
                    if (boton.id.toLowerCase() === categoria.toLowerCase()) {
                        botonesCategorias.forEach(boton => boton.classList.remove("active")); // Eliminar la clase 'active' de todos los botones
                        boton.classList.add("active"); // Añadir la clase 'active' al botón seleccionado
                    }
                });
            } else {
                // Si no hay una categoría en la URL, cargar todos los productos
                cargarProductos(productos);
                //window.alert("no");
            }
        };
    </script>
</body>

</html>