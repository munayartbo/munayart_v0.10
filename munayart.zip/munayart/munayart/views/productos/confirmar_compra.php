<?php
session_start();
include '../../models/db_connection.php'; // Incluye la conexión a la base de datos

// Verificar si el usuario está logueado
if (!isset($_SESSION['user_id'])) {
    echo "Usuario no autenticado. Redirigiendo a la página de inicio...";
    header("Location: ../loginIniReg.php"); // Redirigir al login si no está autenticado
    exit();
}

// Obtener el código del carrito de la URL
$codCarrito = $_GET['codCarrito'] ?? null;
$totalPagar = 0; // Inicializar total a pagar

if ($codCarrito) {
    // Consulta para obtener los productos del carrito y el total
    $stmt = $conn->prepare("
        SELECT 
            p.CodProducto,
            p.Nombre,
            p.Precio,
            i.Cantidad,
            (i.Cantidad * p.Precio) AS Subtotal
        FROM 
            carrito c 
        JOIN 
            incluye i ON c.CodCarrito = i.CodCarrito 
        JOIN 
            producto p ON i.CodProducto = p.CodProducto 
        WHERE 
            c.CodCarrito = ?
    ");
    $stmt->bind_param("i", $codCarrito);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    echo "Error: No se pudo procesar la compra.";
    exit(); // Salir si no hay código de carrito
}

// Cerrar la declaración
$stmt->close();
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Pagos - MunayArt</title>

    <!-- FUENTE GOOGLE FONTS : Poppins -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700;800&display=swap" rel="stylesheet">
    <!-- Mis Estilos -->
    <link rel="stylesheet" href="views/css/estilos.css">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }

        .wrapper {
            max-width: 600px;
            margin: 0 auto;
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }

        .titulo-principal {
            font-size: 24px;
            color: #040f16;
            margin: 10px 0;
        }

        .detalle-facturacion {
            background-color: #f9f9f9;
            border: 1px solid #ddd;
            border-radius: 5px;
            padding: 15px;
            margin-bottom: 20px;
        }

        .detalle-facturacion h3 {
            font-size: 18px;
            color: #040f16;
            margin-bottom: 10px;
        }

        .detalle-facturacion table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 10px;
        }

        .detalle-facturacion th,
        .detalle-facturacion td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        .detalle-facturacion th {
            background-color: #040f16;
            color: white;
        }

        .total {
            font-size: 20px;
            font-weight: 600;
            color: #040f16;
            text-align: right;
        }

        .form-group {
            margin-bottom: 15px;
        }

        label {
            font-weight: 500;
            color: #040f16;
        }

        input[type="text"],
        input[type="radio"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }

        input[type="radio"] {
            width: auto;
            margin-right: 5px;
        }

        button.btn {
            width: 100%;
            height: 50px;
            border-radius: 5px;
            border: none;
            font-size: 18px;
            font-weight: 600;
            background: #040f16;
            color: #f5f5f5;
            transition: all 0.5s ease-in-out;
            margin-top: 10px;
        }

        button.btn:hover {
            box-shadow: 0 0 20px rgba(46, 46, 46, 0.3);
            background: #f17575;
        }
    </style>
</head>

<body>

    <div class="wrapper">
        <header>
            <h2 class="titulo-principal">Detalles de Pago</h2>
        </header>
        <main>
            <!-- Apartado de Detalle de Facturación y Total -->
            <div class="detalle-facturacion">
                <?php
                // Comprobar si hay productos
                echo "<p>Código de Carrito: $codCarrito</p>";
                if (isset($result) && $result->num_rows > 0) {
                    echo "<table>";
                    echo "<thead>
                        <tr>
                            <th>Código Producto</th>
                            <th>Nombre</th>
                            <th>Precio</th>
                            <th>Cantidad</th>
                            <th>Subtotal</th>
                        </tr>
                      </thead>
                      <tbody>";

                    // Mostrar productos
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>
                            <td>{$row['CodProducto']}</td>
                            <td>{$row['Nombre']}</td>
                            <td>Bs. {$row['Precio']}</td>
                            <td>{$row['Cantidad']}</td>
                            <td>Bs. {$row['Subtotal']}</td>
                          </tr>";

                        // Sumar el subtotal al total a pagar
                        $totalPagar += $row['Subtotal'];
                    }

                    echo "</tbody></table>";

                    // Mostrar el total a pagar
                    echo "<p>Total a pagar: Bs. $totalPagar</p>";
                } else {
                    echo "<p>No se encontraron productos en el carrito.</p>";
                } ?>
            </div>

            <form action="procesar_pago.php" method="POST">
                <input type="hidden" name="codCarrito" value="<?= htmlspecialchars($codCarrito); ?>">
                <!-- Campo oculto para el código del carrito -->
                <input type="hidden" name="totalPago" value="<?= htmlspecialchars($totalPagar); ?>">
                <!-- Campo oculto para el total a pagar -->
                
                <div class="form-group">
                    <label for="departamento">Departamento:</label>
                    <input type="text" name="departamento" id="departamento" class="form-control" required>
                </div>

                <div class="form-group">
                    <label for="provincia">Provincia:</label>
                    <input type="text" name="provincia" id="provincia" class="form-control" required>
                </div>

                <div class="form-group">
                    <label for="calle">Calle:</label>
                    <input type="text" name="calle" id="calle" class="form-control" required>
                </div>

                <div class="form-group">
                    <label for="zona">Zona:</label>
                    <input type="text" name="zona" id="zona" class="form-control" required>
                </div>

                <div class="form-group">
                    <label for="nropuerta">Número de puerta:</label>
                    <input type="text" name="nropuerta" id="nropuerta" class="form-control" required>
                </div>

                <div class="form-group">
                    <label>Forma de pago:</label>
                    <div>
                        <input type="radio" id="tarjeta" name="pago" value="tarjeta" checked>
                        <label for="tarjeta">Tarjeta</label>
                    </div>
                    <div>
                        <input type="radio" id="qr" name="pago" value="qr">
                        <label for="qr">QR</label>
                    </div>
                </div>

                <div id="form-tarjeta">
                    <div class="form-group">
                        <label for="numero-tarjeta">Número de tarjeta:</label>
                        <input type="text" id="numero-tarjeta" name="numero-tarjeta" class="form-control"
                            pattern="\d{16}" maxlength="16" placeholder="1234 5678 1234 5678"
                            title="El número de tarjeta debe tener 16 dígitos" required>
                    </div>

                    <div class="form-group">
                        <label for="fecha-expiracion">Fecha de expiración (MM/AA):</label>
                        <input type="text" id="fecha-expiracion" name="fecha-expiracion" class="form-control"
                            pattern="\d{2}/\d{2}" maxlength="5" placeholder="MM/AA"
                            title="Debe ingresar la fecha en formato MM/AA" required>
                    </div>

                    <div class="form-group">
                        <label for="cvv">CVV:</label>
                        <input type="text" id="cvv" name="cvv" class="form-control" pattern="\d{3}" maxlength="3"
                            placeholder="123" title="El CVV debe tener 3 dígitos" required>
                    </div>
                </div>

                <!-- Sección QR -->
                <div id="codigo-qr" style="display: none;">
                    <img src="img/qr.png" id="qr-imagen" alt="Código QR">
                    <p>Escanea el código QR para pagar.</p>
                </div>

                <button id="confirmar-pago" class="btn">Comprar ahora</button>
            </form>
        </main>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="ruta-a-tu-archivo-js/detalle.js"></script>

    <script>
        const formasPago = document.querySelectorAll('input[name="pago"]');
        formasPago.forEach(radio => {
            radio.addEventListener("change", function () {
                if (this.value === "tarjeta") {
                    document.getElementById("form-tarjeta").style.display = "block";
                    document.getElementById("codigo-qr").style.display = "none";
                } else {
                    document.getElementById("form-tarjeta").style.display = "none";
                    document.getElementById("codigo-qr").style.display = "flex";
                }
            });
        });
    </script>

</body>

</html>

<?php
// Cerrar la conexión
$conn->close();
?>
