<?php
include('../../controllers/db_connection.php');
session_start();
$CodUsuario = $_SESSION['user_id'];

// Verificar si el formulario ha sido enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recoger los datos del formulario de la ubicación
    $departamento = $_POST['departamento'];
    $provincia = $_POST['provincia'];
    $calle = $_POST['calle'];
    $zona = $_POST['zona'];
    $nropuerta = $_POST['nropuerta'];
    $totalPago = $_POST['totalPago']; // Total a pagar desde el formulario
    $codCarrito = $_POST['codCarrito']; // Obtener el código del carrito

    // Validar los campos de la ubicación antes de proceder
    if (empty($departamento) || empty($provincia) || empty($calle) || empty($zona) || empty($nropuerta)) {
        echo "Todos los campos son obligatorios.";
    } else {
        // Insertar en la tabla Pago
        $sql_pago = "INSERT INTO Pago (Tipo, Total, CodCarrito)
                     VALUES ('Tarjeta', '$totalPago', '$codCarrito')";

        if ($conn->query($sql_pago) === TRUE) {
            $CodPago = $conn->insert_id; // Obtener el ID del pago insertado
            echo "Pago creado con éxito.<br>";

            // Ahora generamos el pedido
            $fecha = date('Y-m-d H:i:s');
            $estado = 'pendiente';
            $sql_pedido = "INSERT INTO Pedido (Fecha, Estado, CodPago)
                           VALUES ('$fecha', '$estado', '$CodPago')";

            if ($conn->query($sql_pedido) === TRUE) {
                $CodPedido = $conn->insert_id; // Obtener el ID del pedido insertado
                echo "Pedido creado con éxito.<br>";

                // Ahora insertamos en la tabla Ubicación
                $sql_ubicacion = "INSERT INTO Ubicacion (Departamento, Provincia, Calle, Zona, NroPuerta)
                                  VALUES ('$departamento', '$provincia', '$calle', '$zona', '$nropuerta')";

                if ($conn->query($sql_ubicacion) === TRUE) {
                    $CodUbicacion = $conn->insert_id; // Obtener el ID de la ubicación insertada
                    echo "Ubicación guardada con éxito.<br>";

                    // Actualizar el pedido para incluir la ubicación
                    $sql_actualizar_pedido = "UPDATE Pedido SET CodUbicacion = '$CodUbicacion' WHERE CodPedido = '$CodPedido'";
                    if ($conn->query($sql_actualizar_pedido) === TRUE) {
                        echo "Pedido actualizado con la ubicación.<br>";
                    } else {
                        echo "Error al actualizar el pedido con la ubicación: " . $conn->error;
                    }
                } else {
                    echo "Error al guardar la ubicación: " . $conn->error;
                }
            } else {
                echo "Error al crear el pedido: " . $conn->error;
            }
        } else {
            echo "Error al crear el pago: " . $conn->error;
        }
    }
    $conn->close();
}
?>
