<?php
include '../../controllers/db_connection.php';
session_start();
function obtenerTiempoEstimado($departamento) {
    switch ($departamento) {
        case 'La Paz':
            return '30 minutos';
        case 'Potosí':
            return '45 minutos';
        case 'Cochabamba':
            return '60 minutos';
        case 'Oruro':
            return '90 minutos';
        // Agrega más departamentos según sea necesario
        default:
            return 'Tiempo estimado no disponible';
    }
}

if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'cliente') {
    echo "<script>
              alert('No tienes el rol de Cliente');
              window.location.href = '../../views/loginIniReg.php';
          </script>";
    exit();
}

// Obtener el ID del cliente de la sesión
$CodCliente = $_SESSION['user_id'];

// Consulta para obtener los pedidos del cliente
$sql = "
    SELECT 
        p.CodPedido,
        p.Fecha AS FechaPedido,
        p.Estado AS EstadoPedido,
        u.Departamento,
        u.Provincia,
        u.Calle,
        u.Zona,
        u.NroPuerta,
        pg.Tipo AS TipoPago,
        pg.Total AS MontoTotal,
        s.User
    FROM 
        Pedido p
    JOIN Pago pg ON p.CodPago = pg.CodPago
    JOIN Ubicacion u ON p.CodUbicacion = u.CodUbicacion
    JOIN Carrito c ON pg.CodCarrito = c.CodCarrito
    LEFT JOIN Entrega e ON e.CodPedido = p.CodPedido
    LEFT JOIN Delivery d ON e.CodDelivery = d.CodDelivery
    LEFT JOIN Usuario s ON d.CodDelivery = s.CodUsuario
    WHERE c.CodCliente = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $CodCliente);
$stmt->execute();
$result = $stmt->get_result();

// Comprobar si hay resultados
if ($result->num_rows === 0) {
    echo "<script>alert('No tienes pedidos registrados.');</script>";
} else {
    $result->data_seek(0); // Resetear el puntero para volver a utilizar los datos
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mis Pedidos - MunayArt</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: #f0f0f0;
            color: #333;
        }

        .container {
            background-color: #FFFFFF;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
            padding: 40px;
            max-width: 900px;
            width: 100%;
            text-align: center;
            position: relative;
        }

        h2 {
            color: #D64045;
            text-align: left;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ccc;
        }

        th {
            background-color: #D64045;
            color: white;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        button {
            background-color: #D64045;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 5px;
            font-size: 1em;
            cursor: pointer;
        }

        button:hover {
            background-color: #b52e37;
        }

        .no-pedidos {
            margin-top: 20px;
            color: #D64045;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Mis Pedidos</h2>
        <?php if ($result->num_rows === 0): ?>
            <p class="no-pedidos">No tienes pedidos registrados.</p>
        <?php else: ?>
            <table>
                <thead>
                    <tr>
                        <th>Fecha</th>
                        <th>Ubicación</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                        <th>Delivery</th> 
                        <th>Tiempo Estimado</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($pedido = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $pedido['FechaPedido']; ?></td>
                            <td><?php echo "{$pedido['Departamento']}, {$pedido['Provincia']}, {$pedido['Calle']}, {$pedido['Zona']}, Nro: {$pedido['NroPuerta']}"; ?></td>
                            <td><?php echo $pedido['EstadoPedido']; ?></td>
                            <td>
                                <?php 
                                if ($pedido['EstadoPedido'] == 'Pendiente' || $pedido['EstadoPedido'] == 'Aceptado'): ?>
                                    <button onclick="actualizarEstado(<?php echo $pedido['CodPedido']; ?>, 'Cancelado')">Cancelar</button>
                                <?php elseif ($pedido['EstadoPedido'] == 'Entregado'): ?>
                                    <button onclick="actualizarEstado(<?php echo $pedido['CodPedido']; ?>, 'Devolver')">Devolver</button>
                                <?php else: ?>
                                    <span>No disponible</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo $pedido['User'] ?: 'No asignado'; ?></td>
                            <td>
                                <?php
                                // Obtener el tiempo estimado basado en el departamento
                                $departamento = $pedido['Departamento'];
                                echo obtenerTiempoEstimado($departamento);
                                ?>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

    <script>
        function actualizarEstado(codPedido, accion) {
            const mensaje = (accion === 'Cancelado') ? '¿Estás seguro de que deseas cancelar este pedido?' : '¿Estás seguro de que deseas devolver este pedido?';
            if (confirm(mensaje)) {
                window.location.href = `../../controllers/actualizar_pedido.php?CodPedido=${codPedido}&accion=${accion}`;
            }
        }
        
    </script>
</body>
</html>
