<!--Font Awesome CDN-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" referrerpolicy="no-referrer" />




<?php
include '../models/db_connection.php';

// Consulta para obtener los detalles de los artesanos y la comunidad
$sql = "SELECT u.Nombre, u.Apellido, u.Celular, u.Email, a.Descripcion, a.AniosExp, a.Imagen AS ImagenArtesano, c.Imagen AS ImagenComunidad 
        FROM artesano a 
        JOIN usuario u ON a.CodArtesano = u.CodUsuario 
        JOIN comunidad c ON a.CodComunidad = c.CodComunidad";

$result = $conn->query($sql);

?>


<div class="container">
    <div class="slide">

        <?php
        if ($result->num_rows > 0) {
            // Mostrar los resultados de cada fila
            while ($row = $result->fetch_assoc()) {
                echo '<div class="item" style="background-image: url(' . $row["ImagenComunidad"] . ');">';
                                                               
                echo '<div class="content">';
                //echo '<div><img src="imagenes/artesanos/' . $row["ImagenArtesano"] . '" alt="" style="width: 300px; height: 200px;"></div>';
                echo '<div><img src="' . $row["ImagenArtesano"] . '" alt="" style="width: 300px; height: 200px;"></div>';
                echo '<div class="name">' . $row["Nombre"] . ' ' . $row["Apellido"] . '</div>';
                echo '<div class="des">' . $row["Descripcion"] . ' (' . $row["AniosExp"] . ' años de experiencia)</div>';
                echo '<button>See More</button>';
                echo '</div>';
                echo '</div>';
            }
        } else {
            echo "No se encontraron artesanos.";
        }
        $conn->close();
        ?>

    </div>

    <div class="button">
        <button class="prev"><i class="fa-solid fa-arrow-left"></i></button>
        <button class="next"><i class="fa-solid fa-arrow-right"></i></button>
    </div>
</div>

<link rel="stylesheet" href="css/cssMejorArt.css">
<script src="js/jsMejorArt.js"></script>
