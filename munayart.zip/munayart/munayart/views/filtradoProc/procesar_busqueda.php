<?php
// Conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "munayart";
$port = "3307";

$conn = new mysqli($servername, $username, $password, $dbname, $port);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Recibir los datos del formulario
$buscar = $_POST['buscar'] ?? '';
$buscarTipo = $_POST['buscarTipo'] ?? '';
$material = $_POST['material'] ?? '';
$buscapreciodesde = $_POST['buscapreciodesde'] ?? '';
$buscapreciohasta = $_POST['buscapreciohasta'] ?? '';
$orden = $_POST['orden'] ?? '';

// Procesar el filtro de búsqueda
$aKeyword = explode(" ", $buscar);
$query = "SELECT * FROM producto WHERE 1=1";

if (!empty($buscar)) {
    $query .= " AND (nombre LIKE LOWER('%" . $aKeyword[0] . "%') ";
    for ($i = 1; $i < count($aKeyword); $i++) {
        if (!empty($aKeyword[$i])) {
            $query .= " OR nombre LIKE LOWER('%" . $aKeyword[$i] . "%')";
        }
    }
    $query .= ")";
}

if (!empty($buscarTipo)) {
    $query .= " AND tipo = '" . $buscarTipo . "'";
}
if (!empty($buscapreciodesde)) {
    $query .= " AND precio >= '" . $buscapreciodesde . "'";
}
if (!empty($buscapreciohasta)) {
    $query .= " AND precio <= '" . $buscapreciohasta . "'";
}
if (!empty($material)) {
    $query .= " AND material = '" . $material . "'";
}
switch ($orden) {
    case '1':
        $query .= " ORDER BY nombre ASC";
        break;
    case '2':
        $query .= " ORDER BY tipo ASC";
        break;
    case '3':
        $query .= " ORDER BY material ASC";
        break;
    case '4':
        $query .= " ORDER BY precio ASC";
        break;
    case '5':
        $query .= " ORDER BY precio DESC";
        break;
}

$sql = $conn->query($query);
$numeroSql = mysqli_num_rows($sql);

// Generar HTML de los resultados
$html = '';
while ($rowSql = $sql->fetch_assoc()) {
    // Consulta para obtener la calificación promedio del producto
    $queryCalificacion = "SELECT ROUND(AVG(Calificacion), 1) AS promedio_calificacion, COUNT(*) AS total_resenias
                          FROM Resenia
                          WHERE CodProducto = " . $rowSql["CodProducto"];
    $calificacionResult = $conn->query($queryCalificacion);
    $calificacionData = $calificacionResult->fetch_assoc();

    $promedioCalificacion = $calificacionData['promedio_calificacion'] ?? 0;
    $totalResenias = $calificacionData['total_resenias'] ?? 0;

    // Generar estrellas dinámicas
    $estrellas = '';
    for ($i = 1; $i <= 5; $i++) {
        if ($i <= $promedioCalificacion) {
            $estrellas .= '<i class="fa-solid fa-star"></i>';
        } else if ($i <= ceil($promedioCalificacion)) {
            $estrellas .= '<i class="fa-solid fa-star-half-stroke"></i>'; // Media estrella
        } else {
            $estrellas .= '<i class="fa-regular fa-star"></i>';
        }
    }

    // Generar HTML del producto con estrellas
    $html .= '
    <div class="card">
        <div class="imgBox">
            <img src="../productos/' . $rowSql["Imagen"] . '" alt="' . $rowSql["Nombre"] . '">
        </div>
        <div class="info">
            <h2>' . $rowSql["Nombre"] . '</h2>
            <h3>' . $rowSql["Precio"] . ' Bs</h3>
            <div class="rating">
                ' . $estrellas . '
                <span style="font-size: 15px;">' . $promedioCalificacion . '/5 ' . $totalResenias . ' reseñas</span>
            </div>
            <div class="tags">
                <a style="text-decoration: none;" target="_top" href="../Producto_individual/detalles_producto.php?CodProducto=' . $rowSql["CodProducto"] . '">
                <span style="text-decoration: none;">Más</span> </a>
                
                <span style="text-decoration: none;" >Agregar a carrito</span> 
           
            </div>
            <div class="text">
                <p>' . $rowSql["Descripcion"] . '</p>
            </div>
        </div>
    </div>';
}


// Respuesta en JSON
echo json_encode([
    'html' => $html,
    'count' => $numeroSql
]);

$conn->close();
?>