<?php
session_start();
include 'db_connection.php';


// Verificar que el usuario tenga el rol de administrador
if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'administrador') {
    echo "<script>alert('No tienes el rol de Administrador'); window.location.href = '../views/loginIniReg.php';</script>";
    exit();
}

// Procesar datos del formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $titulo = $_POST['titulo'];
    $descripcion = $_POST['descripcion'];
    $fecha_inicio = $_POST['fecha_inicio'];
    $fecha_fin = $_POST['fecha_fin'];
    $cod_producto = $_POST['producto'];

    // Insertar la promoción
    $sql_promocion = "INSERT INTO Promocion (Titulo, Descripcion, FechaInicio, FechaFin) VALUES ('$titulo', '$descripcion', '$fecha_inicio', '$fecha_fin')";
    
    if ($conn->query($sql_promocion) === TRUE) {
        $cod_promocion = $conn->insert_id;  // Obtener el ID de la promoción insertada
        
        // Vincular la promoción con el producto
        $sql_aplica = "INSERT INTO Aplica (CodPromocion, CodProducto) VALUES ('$cod_promocion', '$cod_producto')";
        if ($conn->query($sql_aplica) === TRUE) {
            echo "<script>alert('Promoción añadida con éxito'); window.location.href = '../views/admin_comunidades.php';</script>";
        } else {
            echo "Error al vincular la promoción con el producto: " . $conn->error;
        }
    } else {
        echo "Error al añadir la promoción: " . $conn->error;
    }
}

$conn->close();
?>
